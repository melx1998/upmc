#include <stdio.h>

int main() {
	
  int a = 7.6;
  int b;
  b = 3;
  printf("%d\n", a*2);
  printf("%d\n", b*2);
	
  return 0;
}
