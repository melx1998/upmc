#include <stdio.h>

int main() {
  int a, b;
  float d, c;
  	
  a = 7;
  b = 2.5;
  d = 3.5;
  c = b-d;
  c = c-2;
  b = a/2.0;
  c = a/2.0;
	
  return 0;
}
