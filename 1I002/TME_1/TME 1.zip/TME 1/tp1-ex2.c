#include <stdio.h>

int main() {
  int a;
  a = 14;

  printf("%d\n", a*3);

  return 0;
}
